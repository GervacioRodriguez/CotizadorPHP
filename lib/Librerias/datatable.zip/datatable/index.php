<?php require('config.php'); ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Datatable jQuery plugin ejemplo de Jose Aguilar</title>
<link rel="shortcut icon" href="https://www.jose-aguilar.com/blog/wp-content/themes/jaconsulting/favicon.ico" />
<link rel="stylesheet" href="css/font-awesome.min.css">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css" integrity="sha384-Smlep5jCw/wG7hdkwQ/Z5nLIefveQRIY9nfy6xoR1uRYBtpZgI6339F5dgvm/e9B" crossorigin="anonymous">
<link rel="stylesheet" href="css/styles.css">
<script src="https://code.jquery.com/jquery-3.2.1.js" integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em" crossorigin="anonymous"></script>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.css"/>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.18/datatables.min.js"></script>
<script type="text/javascript">
$(document).ready( function () {
    $('#datatable').DataTable();
} );
</script>
</head>

<body>
<div class="container">
    <div class="row">
        <div id="header" class="col-lg-12">
            <h1>Datatable jQuery plugin ejemplo</h1>
        </div>
    </div>
    <div class="row">
        <div id="content" class="col-lg-12">
<?php
$result = $connexion->query(
    'SELECT * FROM product p 
    LEFT JOIN product_lang pl ON (pl.id_product = p.id_product AND pl.id_lang = 1) 
    LEFT JOIN `image` i ON (i.id_product = p.id_product AND cover = 1) 
    WHERE active = 1 
    ORDER BY date_upd DESC'
);
?>
<?php if ($result->num_rows > 0) { ?>
    <table id="datatable" class="table">
        <thead>
            <tr>
                <th>Imagen</th>
                <th>Referencia</th>
                <th>Version</th>
                <th>Compatibilidad</th>
                <th>Precio</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><img class="img-fluid mx-auto d-block" src="https://www.jose-aguilar.com/modulos-prestashop/<?php echo $row['id_image']; ?>-small_default/<?php echo $row['link_rewrite']; ?>.jpg" width="40" height="40" /></td>
                <td><?php echo utf8_encode($row['name']); ?><br/>Referencia: <?php echo $row['reference']; ?></td>
                <td><?php echo $row['version']; ?></td>
                <td><?php echo $row['compatibility']; ?></td>
                <td><?php echo round($row['price'], 2); ?> EUR</td>
                <td>
                    <a class="btn btn-primary" href="https://www.jose-aguilar.com/modulos-prestashop/es/<?php echo $row['id_product']; ?>-<?php echo $row['link_rewrite']; ?>.html" target="_blank"><i class="fa fa-eye"></i> Ver</a>
                </td>
            </tr>
        <?php } ?>
    </table>
<?php } ?>
        </div>
    </div>

    <div id="footer" class="row">
        <div class="col-xs-12 col-lg-6">
            <iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.facebook.com%2Fpages%2FBlog-Jose-Aguilar-Desarrollo-Web%2F269898786396364&send=false&layout=standard&width=450&show_faces=false&font=lucida+grande&colorscheme=light&action=like&height=35&appId=283652475068166" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100%; height:35px;" allowTransparency="true"></iframe>
        </div>
        <div class=" col-xs-12 col-lg-6">
            <div class="pull-right">
                <a href=" https://www.jose-aguilar.com/blog/datatables-jquery-plugin/" class="btn btn-secondary">
                    <i class="fa fa-reply"></i> volver al tutorial
                </a>
                <a href="https://www.jose-aguilar.com/scripts/jquery/datatable/datatable.zip" class="btn btn-primary">
                    <i class="fa fa-download"></i> Descargar
                </a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
